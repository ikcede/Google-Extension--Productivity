==============================
Google-Extension--Productivity
==============================

DESCRIPTION:
A prototype extension for keeping yourself on track:

v0.3: While productivity is on, all unproductive pages will be filtered. This will be memorized
as you set them per page. 

v0.2: While productivity is on, all pages will be filtered. While it is off, 
no pages will be filtered.

INSTALLATION:
To use, simply download the source into a folder, go to Chrome/settings/tools/extensions,
turn on developer mode, click on Load unpacked extension, browse to the folder, and open it.

Interface + options page to come.

